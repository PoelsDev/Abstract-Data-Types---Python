class TwoThreeFourNode:
    def __init__(self):
        self.keys = []
