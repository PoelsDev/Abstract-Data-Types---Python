def readInput(file):
    """
    +readInput() leest een inputfile en voert de commando's die daarin staan uit om: datatypes te creêren, .dot-files te creëren of om traverses te printen.
    :param file: Het bestand waarin de commando's zouden staan.
    Pre-condities: Het bestand moet commando's bevatten voor het maken van datatypes, het maken van .dot-files of het printen van traverses.
    Post-condities: De commando's in het bestand zullen uitgevoerd worden.
    """
    pass
