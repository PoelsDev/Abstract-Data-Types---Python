class TreeNode:
    def __init__(self, key):
        self.key = key
